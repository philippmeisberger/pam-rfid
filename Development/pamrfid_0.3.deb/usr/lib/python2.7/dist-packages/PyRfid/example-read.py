"""
PyRfid
Example RFID read.

Copyright 2014 Philipp Meisberger (PM Code Works).
All rights reserved. 
"""

from PyRfid import *

   
rfid = PyRfid('/dev/ttyUSB0', 9600)

try:
    print 'Waiting for tag...\n'

    if ( rfid.readTag() != True ):
        raise Exception('User aborted!')

    print 'RAW:      '+ rfid.rawTag
    print 'Checksum: '+ rfid.tagChecksum +'\n'

    print 'Hexadecimal-format:'
    print 'ID:       '+ rfid.tagId
    print 'Type:     '+ rfid.tagType +'\n'

    print 'Decimal-format:'
    print 'ID:       '+ rfid.tagIdDecimal
    print 'Type:     '+ rfid.tagTypeDecimal

except Exception as e:
    print '[Exception] '+ e.message
